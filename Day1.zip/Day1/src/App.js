
import './App.css';
import Title from './Title';

function App() {
  return (
    <><div><h1>This is App Component ......</h1></div><Title /></>
  );
}

export default App;
