import React from 'react';
import './Title.css';

function Title(){
    return (
        <div>This is the Title Component</div>
    );
}
export default Title;
